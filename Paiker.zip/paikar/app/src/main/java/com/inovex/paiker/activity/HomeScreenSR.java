package com.inovex.paiker.activity;

/**
 * Created by DELL on 7/31/2018.
 */

public class HomeScreenSR {
}
