package com.inovex.paiker.volly_method.interfaces;

public interface VolleyCallBack {
    void onSuccess(String result);
}
