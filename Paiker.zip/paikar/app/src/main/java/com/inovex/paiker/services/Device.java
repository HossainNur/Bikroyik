package com.inovex.paiker.services;

public class Device {
    public String deviceName;
    public String deviceAddress;
}

