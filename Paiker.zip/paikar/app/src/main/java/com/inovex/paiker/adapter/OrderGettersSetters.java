package com.inovex.paiker.adapter;

public class OrderGettersSetters {

    String product_id, product_name,product_quantity, total_price, price, discount;

}
